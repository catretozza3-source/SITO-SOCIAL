import CampusApp from "./CampusApp";
import {demoData} from "@/lib/demo";
export const dynamic="force-dynamic";
export default function Home(){return <CampusApp initial={demoData()}/>;}
