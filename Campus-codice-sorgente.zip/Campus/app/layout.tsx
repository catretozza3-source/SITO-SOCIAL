import type { Metadata } from "next";
import "./globals.css";

export const viewport = {width:"device-width",initialScale:1,viewportFit:"cover",themeColor:"#b51f35"};

export const metadata: Metadata = {
  title: "Campus · La tua università, le tue persone",
  description: "Il social che avvicina le persone della tua università. Un progetto di Carlo.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {capable:true,title:"Campus",statusBarStyle:"default"},
  icons: {
    icon: "/logo.jpeg",
    apple: "/logo.jpeg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it">
      <body className="antialiased">{children}</body>
    </html>
  );
}
