"use client";
import {useEffect,useRef} from "react";
import {BadgeCheck,X,Sparkles} from "lucide-react";
import type {Person} from "@/lib/types";
const portraits:Record<string,string>={giulia:"giulia",luca:"luca",sofia:"sofia",matteo:"matteo"};
export function Avatar({person,size=44,story=false}:{person:Person;size?:number;story?:boolean}) {
  const portrait=portraits[person.id];
  return <span className={`avatar ${person.color} ${story?"story-ring":""}`} style={{width:size,height:size,minWidth:size,fontSize:size*.31}}>{portrait?<img src={`/images/${portrait}.jpg`} alt="" loading="lazy"/>:<span>{person.name.split(" ").map(s=>s[0]).slice(0,2).join("")}</span>}</span>;
}
export function Verified({demo=false}:{demo?:boolean}) {return <BadgeCheck className="verified" size={15} aria-label={demo?"Profilo dimostrativo":"Email universitaria verificata"}><title>{demo?"Profilo dimostrativo":"Email universitaria verificata"}</title></BadgeCheck>;}
export function Empty({title,body,action}:{title:string;body:string;action?:React.ReactNode}) {return <div className="empty"><span className="empty-symbol"><Sparkles size={28}/></span><h3>{title}</h3><p>{body}</p>{action}</div>;}
export function Dialog({title,children,onClose,wide=false}:{title:string;children:React.ReactNode;onClose:()=>void;wide?:boolean}) {
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const previous=document.activeElement as HTMLElement|null,overflow=document.body.style.overflow;document.body.style.overflow="hidden";
    const focusable=()=>Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]),a[href],input:not([disabled]),textarea,select,[tabindex="0"]')||[]);
    focusable()[0]?.focus();
    const key=(e:KeyboardEvent)=>{if(e.key==="Escape")onClose();if(e.key==="Tab"){const items=focusable(),first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}};
    document.addEventListener("keydown",key);return()=>{document.body.style.overflow=overflow;document.removeEventListener("keydown",key);previous?.focus();};
  },[onClose]);
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><div ref={ref} className={`dialog ${wide?"wide":""}`} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}><div className="dialog-head"><h2>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Chiudi"><X size={23}/></button></div>{children}</div></div>;
}
export function age(time:number) {const m=Math.max(0,Math.floor((Date.now()-time)/60000));if(m<1)return"ora";if(m<60)return`${m} min`;const h=Math.floor(m/60);if(h<24)return`${h} h`;return`${Math.floor(h/24)} g`;}
