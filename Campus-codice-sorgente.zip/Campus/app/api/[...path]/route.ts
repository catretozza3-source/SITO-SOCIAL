import { ApiError,status,requestCode,verifyCode,bootstrap,mutate,upload,imageResponse } from "@/lib/server";
export const dynamic="force-dynamic";
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}});
async function handle(request:Request) {
  try {
    const path=new URL(request.url).pathname.replace(/^\/api\//,"");
    if(request.method==="GET") {
      if(path==="status")return reply(await status());
      if(path==="bootstrap")return reply(await bootstrap());
      if(path.startsWith("media/"))return await imageResponse(path.slice(6));
    }else if(request.method==="POST") {
      const origin=request.headers.get("Origin");
      if(!origin||origin!==new URL(request.url).origin||request.headers.get("Sec-Fetch-Site")==="cross-site")throw new ApiError(403,"Richiesta non consentita.");
      if(path==="upload")return reply(await upload(request));
      if(!request.headers.get("content-type")?.includes("application/json"))throw new ApiError(415,"Formato richiesta non valido.");
      if(Number(request.headers.get("content-length")||0)>20000)throw new ApiError(413,"Richiesta troppo grande.");
      const body=await request.text();if(body.length>20000)throw new ApiError(413,"Richiesta troppo grande.");
      let input;try{input=JSON.parse(body);}catch{throw new ApiError(400,"Dati non validi.");}
      if(!input||typeof input!=="object"||Array.isArray(input))throw new ApiError(400,"Dati non validi.");
      if(path==="auth/request")return reply(await requestCode(input));
      if(path==="auth/verify")return reply(await verifyCode(input));
      return reply(await mutate(path,input));
    }
    throw new ApiError(404,"Risorsa non trovata.");
  }catch(error) {
    if(error instanceof ApiError)return reply({error:error.message},error.status);
    if(error instanceof Error&&error.message.startsWith("Controlla i campi"))return reply({error:error.message},400);
    return reply({error:"Operazione non riuscita. Riprova tra poco."},500);
  }
}
export const GET=handle;
export const POST=handle;
