import assert from "node:assert/strict";
import {test,beforeEach} from "node:test";
import {DatabaseSync} from "node:sqlite";
import {createRequire} from "node:module";
import {readFile,mkdir} from "node:fs/promises";
import {pathToFileURL} from "node:url";
const require=createRequire(import.meta.url);
const vendor=createRequire(require.resolve("wrangler/package.json"));
const {build}=vendor("esbuild");
await mkdir(".sites-runtime",{recursive:true});
await build({stdin:{contents:'export * from "./lib/server.ts";export {GET,POST} from "./app/api/[...path]/route.ts";',resolveDir:process.cwd(),loader:"ts"},outfile:".sites-runtime/security-bundle.mjs",bundle:true,platform:"node",format:"esm",target:"node24",plugins:[{name:"test-platform",setup(b){
  b.onResolve({filter:/^cloudflare:workers$/},()=>({path:"env",namespace:"mock"}));
  b.onResolve({filter:/chatgpt-auth$/},()=>({path:"identity",namespace:"mock"}));
  b.onLoad({filter:/.*/,namespace:"mock"},args=>({contents:args.path==="env"?"export const env=globalThis.__campusEnv;":"export async function getChatGPTUser(){return globalThis.__campusUser?{userId:globalThis.__campusUser,email:'private@example.test'}:null;}",loader:"js"}));
}}]});
globalThis.__campusEnv={};globalThis.__campusUser=null;
const app=await import(pathToFileURL(process.cwd()+"/.sites-runtime/security-bundle.mjs"));
const nativeFetch=globalThis.fetch;
let sql,sent=[];
function statement(query,args=[]){return{bind(...values){return statement(query,values);},async first(){return sql.prepare(query).get(...args)||null;},async all(){return{results:sql.prepare(query).all(...args)};},async run(){const r=sql.prepare(query).run(...args);return{success:true,meta:{changes:Number(r.changes)}};}};}
beforeEach(async()=>{
  sql?.close();sql=new DatabaseSync(":memory:");sql.exec("PRAGMA foreign_keys=ON");sql.exec(await readFile("drizzle/0000_acoustic_king_bedlam.sql","utf8"));
  Object.keys(globalThis.__campusEnv).forEach(k=>delete globalThis.__campusEnv[k]);
  globalThis.__campusEnv.DB={prepare:q=>statement(q),async batch(stmts){sql.exec("BEGIN");try{const results=[];for(const stmt of stmts)results.push(await stmt.run());sql.exec("COMMIT");return results;}catch(e){sql.exec("ROLLBACK");throw e;}}};
  globalThis.__campusUser=null;sent=[];
  globalThis.fetch=async(url,init)=>{assert.equal(url,"https://api.resend.com/emails");sent.push(JSON.parse(init.body));return Response.json({id:"test-delivery"});};
});
function seed(id,email=`${id}@studenti.univpm.it`){sql.prepare("INSERT INTO profiles(id,university_email,username,name,faculty,bio,color,created_at,verified_at) VALUES(?,?,?,?,?,'','clay',?,?)").run(id,email,id,id,"Economia",Date.now(),Date.now());}
function req(path,input,origin="https://campus.test"){const r=new Request(`https://campus.test/api/${path}`,input===undefined?{}:{method:"POST",headers:{"Content-Type":"application/json",Origin:origin},body:JSON.stringify(input)});return input===undefined?app.GET(r):app.POST(r);}
const codeFrom=()=>sent.at(-1).text.match(/\b\d{6}\b/)[0];
function mailReady(){globalThis.__campusEnv.RESEND_API_KEY="test-only";globalThis.__campusEnv.EMAIL_FROM="Campus <test@example.test>";}
test("University gate rejects spoofed domains and every unverified write",async()=>{
  globalThis.__campusUser="new";
  for(const email of ["x@gmail.com","x@studenti.univpm.it.evil.test","x@fakeunivpm.it","x@sub.studenti.univpm.it","a@studenti.univpm.it\nBcc:bad@test.it"]){assert.equal((await req("auth/request",{email})).status,400);}
  assert.equal((await req("post",{caption:"spoofed",userId:"admin",verified:true})).status,403);
  assert.equal((await req("bootstrap")).status,403);
  globalThis.__campusUser=null;assert.equal((await req("bootstrap")).status,401);
});
test("No provider means no email claim, no code, and no account",async()=>{
  globalThis.__campusUser="carlo";
  assert.equal((await req("auth/request",{email:"s123@studenti.univpm.it"})).status,503);
  assert.equal(sent.length,0);assert.equal(sql.prepare("SELECT count(*) n FROM challenges").get().n,0);
});
test("Code verification creates a unique account, hashes the code and prevents replay",async()=>{
  globalThis.__campusUser="carlo";mailReady();
  const r=await req("auth/request",{email:"  S123@STUDENTI.UNIVPM.IT "});assert.equal(r.status,200);const c=await r.json();
  assert.equal(c.email,"s123@studenti.univpm.it");assert.equal(c.code,undefined);assert.equal(sent.length,1);
  const code=codeFrom();assert.notEqual(sql.prepare("SELECT code_hash FROM challenges").get().code_hash,code);
  assert.equal((await req("auth/request",{email:c.email})).status,429);
  const wrong=code==="000000"?"111111":"000000";
  assert.equal((await req("auth/verify",{challengeId:c.challengeId,code:wrong,name:"Carlo",username:"Carlo_Tozza",faculty:"Economia"})).status,400);
  const input={challengeId:c.challengeId,code,name:"Carlo Tozza",username:"Carlo_Tozza",faculty:"Economia"};
  assert.equal((await req("auth/verify",input)).status,200);
  assert.equal(sql.prepare("SELECT username FROM profiles").get().username,"carlo_tozza");
  assert.equal((await req("auth/verify",input)).status,400);
  const data=await (await req("bootstrap")).json();assert.equal(data.me.verified,true);assert.equal(JSON.stringify(data).includes("s123@studenti.univpm.it"),false);
});
test("Codes are owner-bound, expire and lock after five attempts",async()=>{
  mailReady();globalThis.__campusUser="a";const c=await (await req("auth/request",{email:"a@pm.univpm.it"})).json();const code=codeFrom();
  const valid={challengeId:c.challengeId,code,name:"Student",username:"student",faculty:"Scienze"};
  globalThis.__campusUser="b";assert.equal((await req("auth/verify",valid)).status,400);
  globalThis.__campusUser="a";for(let i=0;i<5;i++)assert.equal((await req("auth/verify",{...valid,code:code==="999999"?"888888":"999999"})).status,400);
  assert.equal((await req("auth/verify",valid)).status,400);
  sql.prepare("UPDATE challenges SET attempts=0,expires_at=?").run(Date.now()-1);
  assert.equal((await req("auth/verify",valid)).status,400);assert.equal(sql.prepare("SELECT count(*) n FROM profiles").get().n,0);
});
test("Duplicate email cannot create a second account and username uniqueness is enforced",async()=>{
  seed("original","shared@studenti.univpm.it");globalThis.__campusUser="second";mailReady();
  const c=await (await req("auth/request",{email:"shared@studenti.univpm.it"})).json();
  assert.equal((await req("auth/verify",{challengeId:c.challengeId,code:codeFrom(),name:"Other",username:"other",faculty:"Economia"})).status,409);
  assert.equal(sql.prepare("SELECT count(*) n FROM profiles").get().n,1);
});
test("Server ownership, CSRF, idempotent likes, saves and delete cascade",async()=>{
  seed("alice");seed("bob");globalThis.__campusUser="alice";
  assert.equal((await req("post",{caption:"Hello",location:"Campus"},"https://evil.test")).status,403);
  assert.equal((await req("post",{caption:"Hello",location:"Campus"})).status,200);
  const postId=sql.prepare("SELECT id FROM posts").get().id;
  globalThis.__campusUser="bob";
  assert.equal((await req("delete",{postId,userId:"alice"})).status,403);
  for(let i=0;i<2;i++)assert.equal((await req("like",{postId,active:true})).status,200);
  await req("save",{postId,active:true});await req("comment",{postId,body:"Hi"});
  const bob=await (await req("bootstrap")).json();assert.equal(bob.posts[0].likes,1);assert.equal(bob.posts[0].saved,true);assert.equal(bob.comments.length,1);
  globalThis.__campusUser="alice";const alice=await (await req("bootstrap")).json();assert.equal(alice.posts[0].saved,false);assert.equal(alice.notices.length,2);
  await req("delete",{postId});assert.equal(sql.prepare("SELECT count(*) n FROM likes").get().n,0);assert.equal(sql.prepare("SELECT count(*) n FROM comments").get().n,0);
});
test("Message reads are limited to participants and client cannot spoof the sender",async()=>{
  seed("alice");seed("bob");seed("charlie");globalThis.__campusUser="alice";
  await req("message",{recipientId:"bob",body:"Private",senderId:"charlie"});
  assert.equal(sql.prepare("SELECT sender_id FROM messages").get().sender_id,"alice");
  globalThis.__campusUser="charlie";assert.equal((await (await req("bootstrap")).json()).messages.length,0);
  globalThis.__campusUser="bob";assert.equal((await (await req("bootstrap")).json()).messages.length,1);
  assert.equal((await req("message",{recipientId:"missing",body:"Hi"})).status,404);
});
test("Photo uploads reject spoofed MIME and author cannot use someone else’s media",async()=>{
  seed("alice");seed("bob");globalThis.__campusUser="alice";
  const stored=new Map();globalThis.__campusEnv.BUCKET={async put(id,bytes){stored.set(id,bytes);}};
  const form=new FormData();form.append("file",new File(["<script>bad</script>"],"bad.jpg",{type:"image/jpeg"}));
  const result=await app.POST(new Request("https://campus.test/api/upload",{method:"POST",headers:{Origin:"https://campus.test"},body:form}));assert.equal(result.status,400);assert.equal(stored.size,0);
  const valid=new FormData();valid.append("file",new File([new Uint8Array([255,216,255,224,0])],"photo.jpg",{type:"image/jpeg"}));
  const upload=await app.POST(new Request("https://campus.test/api/upload",{method:"POST",headers:{Origin:"https://campus.test"},body:valid}));assert.equal(upload.status,200);const {url}=await upload.json();
  globalThis.__campusUser="bob";assert.equal((await req("post",{caption:"Mine?",image:url})).status,400);
  globalThis.__campusUser="alice";assert.equal((await req("post",{caption:"Mine",image:url})).status,200);
});
test("Only current stories are returned; post content persists independently of story expiry",async()=>{
  seed("alice");globalThis.__campusUser="alice";
  await req("post",{caption:"Old story",kind:"story"});sql.prepare("UPDATE posts SET created_at=?").run(Date.now()-86400001);
  await req("post",{caption:"New story",kind:"story"});await req("post",{caption:"Permanent post"});
  const d=await (await req("bootstrap")).json();assert.equal(d.posts.length,2);assert.equal(d.posts.some(p=>p.caption==="Old story"),false);
});
process.on("exit",()=>{globalThis.fetch=nativeFetch;sql?.close();});
