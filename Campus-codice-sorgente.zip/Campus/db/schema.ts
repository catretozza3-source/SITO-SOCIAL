import { integer, primaryKey, sqliteTable, text, index } from "drizzle-orm/sqlite-core";

export const profiles = sqliteTable("profiles", {
  id: text("id").primaryKey(), email: text("university_email").notNull().unique(),
  username: text("username").notNull().unique(), name: text("name").notNull(),
  faculty: text("faculty").notNull().default("Economia"), bio: text("bio").notNull().default(""),
  color: text("color").notNull().default("clay"),
  createdAt: integer("created_at").notNull(), verifiedAt: integer("verified_at").notNull(),
});
export const challenges = sqliteTable("challenges", {
  id: text("id").primaryKey(), owner: text("owner").notNull(), email: text("email").notNull(),
  codeHash: text("code_hash").notNull(), createdAt: integer("created_at").notNull(),
  expiresAt: integer("expires_at").notNull(), attempts: integer("attempts").notNull().default(0),
  consumed: integer("consumed").notNull().default(0), sent: integer("sent").notNull().default(0),
}, t => [index("challenge_owner_idx").on(t.owner,t.createdAt),index("challenge_email_idx").on(t.email,t.createdAt)]);
export const posts = sqliteTable("posts", {
  id:text("id").primaryKey(), authorId:text("author_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  caption:text("caption").notNull(), image:text("image"), location:text("location").notNull().default(""),
  kind:text("kind").notNull().default("post"), createdAt:integer("created_at").notNull(),
},t=>[index("post_time_idx").on(t.createdAt)]);
export const likes = sqliteTable("likes", {
  userId:text("user_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  postId:text("post_id").notNull().references(()=>posts.id,{onDelete:"cascade"}),createdAt:integer("created_at").notNull(),
},t=>[primaryKey({columns:[t.userId,t.postId]})]);
export const saves = sqliteTable("saves", {
  userId:text("user_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  postId:text("post_id").notNull().references(()=>posts.id,{onDelete:"cascade"}),
},t=>[primaryKey({columns:[t.userId,t.postId]})]);
export const follows = sqliteTable("follows", {
  userId:text("user_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  targetId:text("target_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),createdAt:integer("created_at").notNull(),
},t=>[primaryKey({columns:[t.userId,t.targetId]})]);
export const comments = sqliteTable("comments", {
  id:text("id").primaryKey(),authorId:text("author_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  postId:text("post_id").notNull().references(()=>posts.id,{onDelete:"cascade"}),body:text("body").notNull(),createdAt:integer("created_at").notNull(),
});
export const messages = sqliteTable("messages", {
  id:text("id").primaryKey(),senderId:text("sender_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  recipientId:text("recipient_id").notNull().references(()=>profiles.id,{onDelete:"cascade"}),body:text("body").notNull(),createdAt:integer("created_at").notNull(),
},t=>[index("message_sender_idx").on(t.senderId,t.createdAt),index("message_recipient_idx").on(t.recipientId,t.createdAt)]);
export const media = sqliteTable("media", {
  id:text("id").primaryKey(),owner:text("owner").notNull().references(()=>profiles.id,{onDelete:"cascade"}),type:text("type").notNull(),createdAt:integer("created_at").notNull(),
});
export const reports = sqliteTable("reports", {
  id:text("id").primaryKey(),reporter:text("reporter").notNull().references(()=>profiles.id,{onDelete:"cascade"}),
  postId:text("post_id").notNull().references(()=>posts.id,{onDelete:"cascade"}),reason:text("reason").notNull(),createdAt:integer("created_at").notNull(),
});
