import type {SocialData, Person} from "./types";

export function demoData():SocialData {
  const now=Date.now();
  const make=(id:string,name:string,username:string,faculty:string,color:string,following=false):Person=>({id,name,username,faculty,color,following,bio:"Tra lezioni, nuove persone e cose da scoprire. 📍 Ancona",verified:true,followers:83,followingCount:112});
  const me={...make("me","Carlo Tozza","carlo_tozza","Economia","clay"),bio:"Idee, persone e nuovi inizi. ☕\nEconomia · UNIVPM"};
  return {me,people:[me,
    make("giulia","Giulia Rossi","giulia.rossi","Economia","rose",true),
    make("luca","Luca Moretti","luca.moretti","Ingegneria","blue",true),
    make("sofia","Sofia Ricci","sofia.ricci","Medicina","sage"),
    make("matteo","Matteo Conti","matteo.conti","Scienze","sand"),
    make("elena","Elena Mancini","elena.mancini","Agraria","lilac"),
  ],posts:[
    {id:"p1",authorId:"giulia",caption:"Chiudere il portatile e prendersi un po’ di mare. La parte migliore della giornata. 🌊\n#vitadacampus #fuoriaula",image:"/images/coast.jpg",location:"Fuori dall’aula",kind:"post",createdAt:now-1800000,likes:128,liked:false,saved:false},
    {id:"p2",authorId:"luca",caption:"Il nostro gruppo studio: 20% appunti, 80% «ma questo all’esame c’è?» ☕📚\nQualcuno si unisce alla prossima sessione?",image:"/images/study.jpg",location:"Pausa studio",kind:"post",createdAt:now-7200000,likes:76,liked:false,saved:false},
    {id:"p3",authorId:"sofia",caption:"Il bello dell’università? Le persone che incontri lungo la strada. ✨",image:"/images/campus.jpg",location:"Vita universitaria",kind:"post",createdAt:now-14400000,likes:94,liked:false,saved:false},
    {id:"p4",authorId:"me",caption:"Da un’idea per il progetto di economia a un posto per conoscere chi studia accanto a noi. Si comincia da qui. 🚀",image:null,location:"Ancona",kind:"post",createdAt:now-86400000,likes:32,liked:false,saved:false},
    {id:"s1",authorId:"giulia",caption:"Una pausa ce la meritiamo. 🌊",image:"/images/coast.jpg",location:"",kind:"story",createdAt:now-3600000,likes:0,liked:false,saved:false},
    {id:"s2",authorId:"luca",caption:"Sessione studio: si parte ☕",image:"/images/study.jpg",location:"",kind:"story",createdAt:now-5400000,likes:0,liked:false,saved:false},
    {id:"s3",authorId:"sofia",caption:"Nuove persone, nuovi inizi ✨",image:"/images/campus.jpg",location:"",kind:"story",createdAt:now-8000000,likes:0,liked:false,saved:false},
  ],comments:[{id:"c1",authorId:"luca",postId:"p1",body:"La vera terapia dopo la lezione 😂",createdAt:now-900000},{id:"c2",authorId:"sofia",postId:"p1",body:"La prossima volta vengo anch’io!",createdAt:now-600000}],messages:[{id:"m1",senderId:"giulia",recipientId:"me",body:"Ehi Carlo! Come sta andando il progetto di economia? ☺️",createdAt:now-2400000},{id:"m2",senderId:"me",recipientId:"giulia",body:"Sta prendendo forma! L’idea è farci conoscere anche fuori dal nostro corso.",createdAt:now-1800000},{id:"m3",senderId:"luca",recipientId:"me",body:"Domani pomeriggio gruppo studio? 📚",createdAt:now-7200000}],notices:[{id:"n1",authorId:"giulia",type:"like",postId:"p4",createdAt:now-900000},{id:"n2",authorId:"sofia",type:"follow",postId:null,createdAt:now-7200000}]};
}

export function demoMutation(data:SocialData,action:string,input:Record<string,any>):SocialData {
  const d=structuredClone(data), now=Date.now(), id=crypto.randomUUID();
  const post=d.posts.find(p=>p.id===input.postId);
  if(action==="like"&&post){post.likes+=input.active===post.liked?0:input.active?1:-1;post.liked=input.active;}
  if(action==="save"&&post)post.saved=input.active;
  if(action==="comment"&&post)d.comments.push({id,authorId:d.me.id,postId:post.id,body:input.body,createdAt:now});
  if(action==="delete"){d.posts=d.posts.filter(p=>p.id!==input.postId||p.authorId!==d.me.id);d.comments=d.comments.filter(c=>c.postId!==input.postId);}
  if(action==="follow"){const p=d.people.find(p=>p.id===input.targetId);if(p&&p.following!==input.active){p.following=input.active;p.followers+=input.active?1:-1;d.me.followingCount+=input.active?1:-1;}}
  if(action==="message")d.messages.push({id,senderId:d.me.id,recipientId:input.recipientId,body:input.body,createdAt:now});
  if(action==="post")d.posts.unshift({id,authorId:d.me.id,caption:input.caption,image:input.image||null,location:input.location,kind:input.kind||"post",createdAt:now,likes:0,liked:false,saved:false});
  if(action==="profile"){Object.assign(d.me,{name:input.name,bio:input.bio,faculty:input.faculty});const p=d.people.find(p=>p.id===d.me.id);if(p)Object.assign(p,d.me);}
  return d;
}
