export type Person = {id:string; username:string; name:string; faculty:string; bio:string; color:string; verified:boolean; following:boolean; followers:number; followingCount:number};
export type Comment = {id:string; authorId:string; postId:string; body:string; createdAt:number};
export type Post = {id:string; authorId:string; caption:string; image:string|null; location:string; kind:string; createdAt:number; likes:number; liked:boolean; saved:boolean};
export type Message = {id:string; senderId:string; recipientId:string; body:string; createdAt:number};
export type Notice = {id:string; authorId:string; type:string; postId:string|null; createdAt:number};
export type SocialData = {me:Person; people:Person[]; posts:Post[]; comments:Comment[]; messages:Message[]; notices:Notice[]};
export const FACULTIES = ["Economia", "Ingegneria", "Medicina", "Scienze", "Agraria"];
