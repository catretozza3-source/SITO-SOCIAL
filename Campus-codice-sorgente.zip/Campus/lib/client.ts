export async function api<T=any>(path:string,input?:Record<string,unknown>):Promise<T> {
  const response=await fetch(`/api/${path}`,input?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(input)}:{cache:"no-store"});
  let result:any;try{result=await response.json();}catch{throw new Error("Il servizio non è disponibile in questo momento.");}
  if(!response.ok)throw new Error(result.error||"Operazione non riuscita.");return result;
}
export async function preparePhoto(file:File) {
  if(!["image/jpeg","image/png","image/webp"].includes(file.type)||file.size>6000000)throw new Error("Scegli una foto JPG, PNG o WebP sotto 6 MB.");
  const bitmap=await createImageBitmap(file,{imageOrientation:"from-image"});
  const ratio=Math.min(1,1400/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement("canvas");canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);
  const ctx=canvas.getContext("2d");if(!ctx)throw new Error("Impossibile preparare la foto.");ctx.fillStyle="#ffffff";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error("Foto non leggibile.")),"image/jpeg",.84));
  const dataUrl=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(new Error("Foto non leggibile."));r.readAsDataURL(blob);});
  return {file:new File([blob],"campus-photo.jpg",{type:"image/jpeg"}),url:dataUrl};
}
