export const UNIVERSITY_DOMAINS = ["studenti.univpm.it", "pm.univpm.it"] as const;
export function universityEmail(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const email=value.trim().toLowerCase();
  if(email.length>254 || !/^[a-z0-9][a-z0-9._+-]*@[a-z0-9.-]+$/.test(email)) return null;
  return UNIVERSITY_DOMAINS.some(domain=>domain===email.split("@")[1])?email:null;
}
export function username(value: unknown): string | null {
  if(typeof value!=="string") return null;
  const name=value.trim().toLowerCase(); return /^[a-z0-9_]{3,24}$/.test(name)?name:null;
}
export function textValue(value:unknown,max:number,required=true):string {
  const result=typeof value==="string"?value.trim():"";
  if((required&&!result)||result.length>max) throw new Error("Controlla i campi: il testo è mancante o troppo lungo.");
  return result;
}
export async function hashCode(id:string,code:string) {
  const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(`${id}:${code}`));
  return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("");
}
export function makeCode() {
  const n=new Uint32Array(1); do{crypto.getRandomValues(n);}while(n[0]>=4294000000);
  return String(n[0]%1000000).padStart(6,"0");
}
