import { env } from "cloudflare:workers";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { FACULTIES } from "./types";
import { universityEmail, username, textValue, hashCode, makeCode } from "./policy";

type Row = Record<string, any>;
export class ApiError extends Error { constructor(public status:number,message:string) { super(message); } }
function db() { if(!env.DB) throw new ApiError(503,"Archivio temporaneamente non disponibile."); return env.DB; }
function row(sql:string,...values:any[]) { return db().prepare(sql).bind(...values).first<Row>(); }
async function all(sql:string,...values:any[]) { return (await db().prepare(sql).bind(...values).all<Row>()).results; }
function run(sql:string,...values:any[]) { return db().prepare(sql).bind(...values).run(); }
export async function identity() { const user=await getChatGPTUser(); if(!user) throw new ApiError(401,"Accedi per verificare la tua email universitaria."); return user.userId; }
export async function member() { const id=await identity(); const me=await row("SELECT * FROM profiles WHERE id = ?",id); if(!me) throw new ApiError(403,"Verifica prima la tua email universitaria."); return me; }
function person(p:Row):any { return {id:p.id,username:p.username,name:p.name,faculty:p.faculty,bio:p.bio,color:p.color,verified:!!p.verified_at,following:!!p.following,followers:Number(p.followers||0),followingCount:Number(p.following_count||0)}; }
export async function status() {
  const u=await getChatGPTUser(); const me=u&&env.DB?await row("SELECT * FROM profiles WHERE id=?",u.userId):null;
  return {signedIn:!!u,registered:!!me,emailReady:!!(env.RESEND_API_KEY&&env.EMAIL_FROM),domains:["studenti.univpm.it","pm.univpm.it"]};
}
export async function requestCode(input:Row) {
  const owner=await identity();
  if(await row("SELECT id FROM profiles WHERE id=?",owner)) throw new ApiError(409,"Hai già un profilo universitario verificato.");
  const email=universityEmail(input.email);
  if(!email) throw new ApiError(400,"Usa la tua email @studenti.univpm.it o @pm.univpm.it.");
  if(!env.RESEND_API_KEY||!env.EMAIL_FROM) throw new ApiError(503,"Le registrazioni apriranno quando sarà attivato l’invio delle email. Puoi già esplorare la demo.");
  const now=Date.now(), id=crypto.randomUUID(), code=makeCode();
  // The guarded INSERT throttles concurrent requests atomically.
  const result=await run(`INSERT INTO challenges(id,owner,email,code_hash,created_at,expires_at,attempts,consumed,sent)
    SELECT ?,?,?,?,?,?,0,0,0 WHERE
    NOT EXISTS (SELECT 1 FROM challenges WHERE (owner=? OR email=?) AND created_at>?)
    AND (SELECT count(*) FROM challenges WHERE (owner=? OR email=?) AND created_at>?) < 5`,
    id,owner,email,await hashCode(id,code),now,now+600000,owner,email,now-60000,owner,email,now-3600000);
  if(!result.meta.changes) throw new ApiError(429,"Attendi un minuto prima di richiedere un nuovo codice. Massimo 5 invii all’ora.");
  let response:Response;
  try {
    response=await fetch("https://api.resend.com/emails",{method:"POST",signal:AbortSignal.timeout(15000),headers:{Authorization:`Bearer ${env.RESEND_API_KEY}`,"Content-Type":"application/json","User-Agent":"CampusUniversity/1.0","Idempotency-Key":id},body:JSON.stringify({from:env.EMAIL_FROM,to:[email],subject:"Il tuo codice di accesso a Campus",text:`Il tuo codice è ${code}. Scade tra 10 minuti. Se non lo hai richiesto, ignora questa email. Non condividerlo con nessuno.`})});
  }catch{throw new ApiError(502,"Non è stato possibile inviare l’email. Riprova tra un minuto.");}
  if(!response.ok) throw new ApiError(502,"Invio email non disponibile. Riprova più tardi.");
  await run("UPDATE challenges SET sent=1 WHERE id=?",id); return {challengeId:id,email};
}
export async function verifyCode(input:Row) {
  const owner=await identity(), id=textValue(input.challengeId,80), code=textValue(input.code,6);
  if(!/^\d{6}$/.test(code)) throw new ApiError(400,"Inserisci il codice di 6 cifre ricevuto via email.");
  const handle=username(input.username), name=textValue(input.name,60);
  if(!handle) throw new ApiError(400,"Il nome utente deve avere 3–24 lettere, numeri o trattini bassi.");
  const faculty=FACULTIES.includes(input.faculty)?input.faculty:"Economia";
  if(await row("SELECT id FROM profiles WHERE username=? AND id<>?",handle,owner)) throw new ApiError(409,"Questo nome utente è già in uso. Scegline un altro.");
  const c=await row(`UPDATE challenges SET attempts=attempts+1 WHERE id=? AND owner=? AND consumed=0 AND sent=1 AND expires_at>? AND attempts<5 RETURNING *`,id,owner,Date.now());
  if(!c||c.code_hash!==await hashCode(id,code)) throw new ApiError(400,"Codice errato, scaduto o già utilizzato. Richiedine un altro se necessario.");
  const now=Date.now();
  try {
    // Profile creation and code consumption commit together. A code can create only one account.
    await db().batch([
      db().prepare(`INSERT INTO profiles(id,university_email,username,name,faculty,bio,color,created_at,verified_at)
        SELECT ?,?,?,?,?,'','clay',?,? FROM challenges WHERE id=? AND owner=? AND consumed=0 AND attempts<=5 AND expires_at>?`).bind(owner,c.email,handle,name,faculty,now,now,id,owner,now),
      db().prepare("UPDATE challenges SET consumed=1 WHERE owner=?").bind(owner),
    ]);
  }catch{throw new ApiError(409,"Email o nome utente già associati a un profilo. Verifica i dati prima di riprovare.");}
  if(!await row("SELECT id FROM profiles WHERE id=?",owner)) throw new ApiError(400,"Questo codice è già stato usato.");
  return {ok:true};
}
export async function bootstrap() {
  const me=await member(), id=me.id;
  const people=await all(`SELECT p.*,
    EXISTS(SELECT 1 FROM follows WHERE user_id=? AND target_id=p.id) AS following,
    (SELECT count(*) FROM follows WHERE target_id=p.id) AS followers,
    (SELECT count(*) FROM follows WHERE user_id=p.id) AS following_count
    FROM profiles p ORDER BY p.created_at DESC LIMIT 250`,id);
  const posts=await all(`SELECT p.*,
    (SELECT count(*) FROM likes WHERE post_id=p.id) AS likes,
    EXISTS(SELECT 1 FROM likes WHERE post_id=p.id AND user_id=?) AS liked,
    EXISTS(SELECT 1 FROM saves WHERE post_id=p.id AND user_id=?) AS saved
    FROM posts p WHERE kind='post' OR created_at>? ORDER BY created_at DESC LIMIT 100`,id,id,Date.now()-86400000);
  const comments=await all(`SELECT c.* FROM comments c WHERE c.post_id IN(SELECT id FROM posts ORDER BY created_at DESC LIMIT 100) ORDER BY c.created_at ASC LIMIT 1000`);
  const messages=await all(`SELECT * FROM (SELECT * FROM messages WHERE sender_id=? OR recipient_id=? ORDER BY created_at DESC LIMIT 300) ORDER BY created_at ASC`,id,id);
  const notices=await all(`SELECT * FROM (
    SELECT l.user_id AS author_id,'like' AS type,l.post_id,l.created_at,'like:'||l.user_id||':'||l.post_id AS id FROM likes l JOIN posts p ON p.id=l.post_id WHERE p.author_id=? AND l.user_id<>?
    UNION ALL SELECT c.author_id,'comment',c.post_id,c.created_at,'comment:'||c.id FROM comments c JOIN posts p ON p.id=c.post_id WHERE p.author_id=? AND c.author_id<>?
    UNION ALL SELECT f.user_id,'follow',NULL,f.created_at,'follow:'||f.user_id FROM follows f WHERE f.target_id=?
    ) ORDER BY created_at DESC LIMIT 50`,id,id,id,id,id);
  return {me:person(people.find(p=>p.id===id)||me),people:people.map(person),posts:posts.map(p=>({id:p.id,authorId:p.author_id,caption:p.caption,image:p.image,location:p.location,kind:p.kind,createdAt:p.created_at,likes:p.likes,liked:!!p.liked,saved:!!p.saved})),comments:comments.map(c=>({id:c.id,authorId:c.author_id,postId:c.post_id,body:c.body,createdAt:c.created_at})),messages:messages.map(m=>({id:m.id,senderId:m.sender_id,recipientId:m.recipient_id,body:m.body,createdAt:m.created_at})),notices:notices.map(n=>({id:n.id,authorId:n.author_id,type:n.type,postId:n.post_id,createdAt:n.created_at}))};
}
export async function mutate(action:string,input:Row) {
  const me=await member(), now=Date.now();
  if(action==="profile") {
    const name=textValue(input.name,60), bio=textValue(input.bio,180,false);
    if(!FACULTIES.includes(input.faculty)) throw new ApiError(400,"Seleziona la tua area di studio.");
    await run("UPDATE profiles SET name=?,bio=?,faculty=? WHERE id=?",name,bio,input.faculty,me.id);
  }else if(action==="post") {
    const caption=textValue(input.caption,2200,false), location=textValue(input.location,80,false);
    const image=input.image?textValue(input.image,100):null;
    if(!caption&&!image) throw new ApiError(400,"Aggiungi una foto o scrivi qualcosa.");
    if(image&&(!image.startsWith("/api/media/")||!await row("SELECT id FROM media WHERE id=? AND owner=?",image.slice(11),me.id))) throw new ApiError(400,"Carica una tua foto prima di pubblicare.");
    const recent=await row("SELECT count(*) AS n FROM posts WHERE author_id=? AND created_at>?",me.id,now-60000);
    if(recent&&recent.n>=5) throw new ApiError(429,"Attendi un minuto prima di pubblicare ancora.");
    await run("INSERT INTO posts(id,author_id,caption,image,location,kind,created_at) VALUES(?,?,?,?,?,?,?)",crypto.randomUUID(),me.id,caption,image,location,input.kind==="story"?"story":"post",now);
  }else if(["like","save","comment","delete","report"].includes(action)) {
    const p=await row("SELECT * FROM posts WHERE id=?",textValue(input.postId,80));
    if(!p) throw new ApiError(404,"Questo post non è più disponibile.");
    if(action==="like"||action==="save") {
      const table=action==="like"?"likes":"saves";
      if(input.active===true) { if(action==="like") await run("INSERT OR IGNORE INTO likes(user_id,post_id,created_at) VALUES(?,?,?)",me.id,p.id,now);else await run("INSERT OR IGNORE INTO saves(user_id,post_id) VALUES(?,?)",me.id,p.id); }
      else await run(`DELETE FROM ${table} WHERE user_id=? AND post_id=?`,me.id,p.id);
    }else if(action==="comment") {
      await run("INSERT INTO comments(id,author_id,post_id,body,created_at) VALUES(?,?,?,?,?)",crypto.randomUUID(),me.id,p.id,textValue(input.body,1000),now);
    }else if(action==="report") {
      await run("INSERT INTO reports(id,reporter,post_id,reason,created_at) VALUES(?,?,?,?,?)",crypto.randomUUID(),me.id,p.id,textValue(input.reason,500),now);
    }else{if(p.author_id!==me.id)throw new ApiError(403,"Puoi eliminare solo i tuoi post.");await run("DELETE FROM posts WHERE id=? AND author_id=?",p.id,me.id);}
  }else if(action==="follow") {
    const target=textValue(input.targetId,80);
    if(target===me.id||!await row("SELECT id FROM profiles WHERE id=?",target))throw new ApiError(400,"Profilo non disponibile.");
    if(input.active===true)await run("INSERT OR IGNORE INTO follows(user_id,target_id,created_at) VALUES(?,?,?)",me.id,target,now);
    else await run("DELETE FROM follows WHERE user_id=? AND target_id=?",me.id,target);
  }else if(action==="message") {
    const target=textValue(input.recipientId,80), body=textValue(input.body,2000);
    if(target===me.id||!await row("SELECT id FROM profiles WHERE id=?",target))throw new ApiError(404,"Destinatario non disponibile.");
    const recent=await row("SELECT count(*) AS n FROM messages WHERE sender_id=? AND created_at>?",me.id,now-60000);
    if(recent&&recent.n>=30)throw new ApiError(429,"Attendi un minuto prima di inviare altri messaggi.");
    await run("INSERT INTO messages(id,sender_id,recipient_id,body,created_at) VALUES(?,?,?,?,?)",crypto.randomUUID(),me.id,target,body,now);
  }else throw new ApiError(404,"Operazione non disponibile.");
  return {ok:true};
}
export async function upload(request:Request) {
  const me=await member();if(!env.BUCKET)throw new ApiError(503,"Archivio foto non disponibile.");
  if(Number(request.headers.get("content-length")||0)>6500000)throw new ApiError(413,"La foto deve pesare meno di 6 MB.");
  const form=await request.formData(), file=form.get("file");
  if(!file||typeof file==="string"||file.size>6000000)throw new ApiError(400,"Scegli una foto JPG, PNG o WebP sotto 6 MB.");
  const bytes=new Uint8Array(await file.arrayBuffer());let type="";
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)type="image/jpeg";
  if(bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71&&bytes[4]===13&&bytes[5]===10&&bytes[6]===26&&bytes[7]===10)type="image/png";
  if(new TextDecoder().decode(bytes.slice(0,4))==="RIFF"&&new TextDecoder().decode(bytes.slice(8,12))==="WEBP")type="image/webp";
  if(!type)throw new ApiError(400,"Formato non supportato. Usa JPG, PNG o WebP.");
  const recent=await row("SELECT count(*) AS n FROM media WHERE owner=? AND created_at>?",me.id,Date.now()-3600000);
  if(recent&&recent.n>=30)throw new ApiError(429,"Hai raggiunto il limite di 30 foto all’ora.");
  const id=crypto.randomUUID();await env.BUCKET.put(id,bytes,{httpMetadata:{contentType:type}});
  await run("INSERT INTO media(id,owner,type,created_at) VALUES(?,?,?,?)",id,me.id,type,Date.now());return {url:`/api/media/${id}`};
}
export async function imageResponse(id:string) {
  await member();if(!/^[0-9a-f-]{36}$/.test(id))throw new ApiError(404,"Foto non trovata.");
  const object=await env.BUCKET?.get(id);if(!object)throw new ApiError(404,"Foto non trovata.");
  return new Response(object.body,{headers:{"Content-Type":object.httpMetadata?.contentType||"image/jpeg","Cache-Control":"private, max-age=3600","X-Content-Type-Options":"nosniff"}});
}
