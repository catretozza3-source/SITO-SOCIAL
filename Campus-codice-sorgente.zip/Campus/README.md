# Campus — social universitario

Prima versione di una web app per telefono per il progetto di economia di Carlo. “Campus” è un nome provvisorio. Progetto indipendente, senza affiliazione ufficiale con UNIVPM.

## Cosa comprende

- Feed con foto e testo, like, commenti, post salvati e condivisione tramite link.
- Storie che restano visibili per 24 ore, profili modificabili, follower, ricerca per persone e area di studio.
- Messaggi tra studenti con aggiornamento periodico ogni 20 secondi quando la pagina è aperta.
- Foto su R2 e dati strutturati su D1. I messaggi sono restituiti soltanto ai partecipanti.
- Demo separata: nomi, immagini e interazioni di esempio, con modifiche salvate esclusivamente nel browser.

## Accesso universitario

L’anteprima privata usa l’identità gestita da Sites/ChatGPT. Questo accesso da solo **non** crea un profilo Campus e non dà accesso ai dati reali. Il server richiede anche la verifica di una casella `studenti.univpm.it` o `pm.univpm.it`. Nessuna password universitaria viene richiesta.

La registrazione reale non è attiva finché l’invio email non è configurato. Configurare `RESEND_API_KEY` e `EMAIL_FROM` come segreti del server, con un dominio mittente verificato su Resend. Non incollare chiavi nel codice o nella chat. Il codice verifica il dominio esatto, normalizza le email, invia un codice casuale di sei cifre, memorizza soltanto l’hash e accetta al massimo cinque tentativi entro dieci minuti. Invii limitati a uno al minuto e cinque all’ora per identità o indirizzo. Email e nome utente sono univoci.

Fonti: [UNIVPM — E@mail](https://www.univpm.it/Entra/Email), [Resend — invio email](https://resend.com/docs/api-reference/emails/send-email).

## Sviluppo e controlli

Usare il flusso Sites e preservare `.openai/hosting.json`, il repository sorgente, la configurazione Vinext e le migrazioni in `drizzle/`. `DB` e `BUCKET` vengono collegati in hosting.

```sh
node node_modules/typescript/bin/tsc --noEmit
node --test tests/security.mjs
```

I test usano SQLite in memoria, un’identità simulata e un trasporto email simulato: non inviano email. Verificano dominio, autenticazione e verifica universitaria, scadenza e riutilizzo dei codici, limiti dei tentativi, duplicati, proprietà dei post, idempotenza dei like, isolamento dei messaggi, CSRF e proprietà dei media.

## Limiti della prima versione

Non è un’app nativa pubblicata negli store. È una web app responsive con manifest per l’apertura dalla schermata Home. Non include notifiche push, video/reel, gruppi, algoritmo di raccomandazione o un sistema operativo di moderazione: le segnalazioni vengono registrate per una successiva revisione. La verifica email prova il controllo della casella, non l’iscrizione universitaria corrente; la verifica periodica è un’evoluzione futura.

Il caricamento iniziale comprende gli ultimi 100 contenuti, fino a 250 profili, fino a 1.000 commenti e gli ultimi 300 messaggi della persona autenticata. Prima di una diffusione ampia occorrono paginazione, moderazione e gestione del ciclo di vita degli account. Nessuna credenziale reale è inclusa nel repository.

## Immagini

Logo fornito da Carlo. Foto dimostrative da Unsplash, scaricate e incluse in `public/images/`:

- Mare: `photo-1518837695005-2083093ee35b`
- Studio: `photo-1499750310107-5fef28a66643`
- Vita universitaria: `photo-1523240795612-9a054b0db644`
- Ritratti dimostrativi: `photo-1531123897727-8f129e1688ce`, `photo-1500648767791-00dcc994a43e`, `photo-1524504388940-b1c1722653e1`, `photo-1506794778202-cad84cf45f1d`.
